#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__

// Wifi parameters
char passphrase[]   = "WPA2 Passphrase Goes Here";
char ssid[]         = "SSID Goes Here";
String apikey       = String("API Key Goes Here");

#endif
