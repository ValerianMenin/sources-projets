#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__

// supply your own Pachube feed ID
#define PACHUBEFEED "36718"
// this API key will only work from my IP address - you need to supply your own
#define APIKEY "v1tYYhpjSApMwXsrdWYd5w2pj8_wSdgsd3R8odYqInM"
#define TIMETOUPDATE 15000  // frequency of update - every 15 seconds

// Wifi parameters
char passphrase[] = "your passphrase here";
char ssid[] = "your ssid";
boolean mode = WPA_MODE; //or WEP_MODE

#endif
