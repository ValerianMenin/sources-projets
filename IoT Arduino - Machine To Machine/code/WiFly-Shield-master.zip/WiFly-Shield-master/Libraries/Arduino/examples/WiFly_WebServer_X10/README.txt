This is a dirty example of using the WiFly shield in conjunction with an X10 Powerline module to turn on/off lights.

The code needs to be cleaned up.