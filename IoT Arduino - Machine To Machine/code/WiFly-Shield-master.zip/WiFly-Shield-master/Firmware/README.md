WiFi_Electric_Blanket
=====================

Example Arduino sketch for the WiFly Shield from SparkFun. This code is used to serve up a webpage and control an electric blanket 

The project description can be found [here](https://www.sparkfun.com/news/1062). 

This was developed for Arduino 1.0+. You will need version 1.0 or greater to use it. 